package PresentationLayer;

import DomainImpLayer.AutoSnelheidImpl;

import javax.swing.*;

public class AbstractServer extends JOptionPane implements AutoSnelheidImpl {
    @Override
    public int vraagWaarde() {

        String waarde = JOptionPane.showInputDialog("Snelheid: ");

        //parsed de ingevoerde snelheids waarde
        return Integer.parseInt(waarde);
    }
}
