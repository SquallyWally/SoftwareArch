package PresentationLayer;


import DomainImpLayer.Snelheid;
import InfrastructureLayer.Observer;

class DigitaleMeter extends javax.swing.JLabel implements Observer {
    private Snelheid S;

    public DigitaleMeter(Snelheid s) {
        S = s;
        s.insertObserver(this);
    }

    public void update() {
        setText(String.valueOf(S.waarde()));
        System.out.println("Digitale meter is " + S.toString());
    }


}