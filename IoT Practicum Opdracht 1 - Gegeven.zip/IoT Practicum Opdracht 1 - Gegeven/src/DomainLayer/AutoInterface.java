package DomainLayer;

import DomainImpLayer.Snelheid;

public interface AutoInterface {

    public Snelheid snelheid();

    public void naarSnelheid();
}
