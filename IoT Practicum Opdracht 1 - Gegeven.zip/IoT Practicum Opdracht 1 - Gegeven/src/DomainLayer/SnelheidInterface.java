package DomainLayer;

import DomainImpLayer.Snelheid;

public interface SnelheidInterface {
   public int waarde();
    public void verhoog();
    public void verlaag();
}
