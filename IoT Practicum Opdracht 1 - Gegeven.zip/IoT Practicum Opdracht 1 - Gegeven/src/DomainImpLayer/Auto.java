package DomainImpLayer;


import DomainLayer.AutoInterface;

public class Auto implements AutoSnelheidImpl, AutoInterface {
    private Snelheid HuidigeSnelheid;
    private int GewensteSnelheid;

    public Auto() {
        HuidigeSnelheid = new Snelheid();
        GewensteSnelheid = 0;
    }

    public Snelheid snelheid() {
        return HuidigeSnelheid;
    }

    public void setGewensteSnelheid(AutoSnelheidImpl autosnelheidimp) {
        GewensteSnelheid = autosnelheidimp.vraagWaarde();
        naarSnelheid();
        System.out.println(GewensteSnelheid);
    }

    public void naarSnelheid() {
        while (HuidigeSnelheid.waarde() < GewensteSnelheid) HuidigeSnelheid.verhoog();
        while (HuidigeSnelheid.waarde() > GewensteSnelheid) HuidigeSnelheid.verlaag();
    }

    @Override
    public int vraagWaarde() {
        return HuidigeSnelheid.waarde();
    }
}

