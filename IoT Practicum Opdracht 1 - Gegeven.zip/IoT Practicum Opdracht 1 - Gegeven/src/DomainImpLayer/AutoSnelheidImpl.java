package DomainImpLayer;

public interface AutoSnelheidImpl {
    int vraagWaarde();
}
