package DomainImpLayer;

import DomainLayer.SnelheidInterface;

import InfrastructureLayer.Subject;

public class Snelheid implements SnelheidInterface , Subject {
    private int Waarde;

    public Snelheid() {
        Waarde = 0;
    }

    public int waarde() {
        return Waarde;
    }

    public void verhoog() {
        System.out.println("HIGHAH");
        Waarde++;

        //Notificeert de Observer, zo niet dan geeft die niet de analoge en digitale waardes aan
        notifyObservers();
    } // Simulatie

    public void verlaag() {
        System.out.println("LOWAH");
        Waarde--;

        //Notificeert de Observer, zo niet dan geeft die niet de analoge en digitale waardes aan
        notifyObservers();
    } // Simulatie
}
