package InfrastructureLayer;


public interface Observer {
     void update();
}